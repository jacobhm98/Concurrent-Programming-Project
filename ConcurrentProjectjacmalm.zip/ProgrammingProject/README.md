# Concurrent Programming Project ID1217

The final project in the concurrent programming course, ID1217. In this project we aim to develop programs which solve Laplace's Partial Differential Equation in 2 dimensions. This will be accomplished using 2 methods, Jacobi and Multigrid. Both of these methods will be developed in a sequential and concurrent form. Parallelization will be done using OpenMP and/or the POSIX Thread library.

Jacob Hedén Malm and Konstantinos Xyderos
